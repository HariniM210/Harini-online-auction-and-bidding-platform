import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../layout/Navbar';
import Footer from '../layout/Footer';

const AuthLayout = ({ children }) => {
  return (
    <div className="auth-page">
      <Navbar />
      <main className="auth-container">
        <div className="auth-wrapper">
          <div className="auth-content">
            {children}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AuthLayout;