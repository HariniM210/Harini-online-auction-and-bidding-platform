import React, { useState } from 'react';

const AuthInput = ({
  type,
  label,
  placeholder,
  value,
  onChange,
  error,
  required = false,
  icon = null,
  showPassword = false,
  buttonText = '',
  buttonAction = null
}) => {
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);

  return (
    <div className="auth-input-group">
      <label htmlFor={`auth-input-${label}`} className="auth-input-label">
        {label}
        {required && <span className="auth-input-required">*</span>
      </label>
      <div className="auth-input-wrapper">
        <input
          id={`auth-input-${label}`}
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          className="auth-input-field"
          required={required}
        />
        {showPassword && type === 'password' && (
          <button
            type="button"
            className="auth-toggle-password"
            onClick={() => setIsPasswordVisible(!isPasswordVisible)}
            aria-label={isPasswordVisible ? 'Hide password' : 'Show password'}
          >
            {isPasswordVisible ? 'text' : 'visibility'}
          </button>
        )}
        {icon && (
          <div className="auth-input-icon">
            {icon}
          </div>
        )}
        {error && (
          <p className="auth-input-error">{error}</p>
        )}
      </div>
    </div>
  );
};

export default AuthInput;