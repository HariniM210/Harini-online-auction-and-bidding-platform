import React, { useState } from 'react';

const PasswordInput = ({
  value,
  onChange,
  showPassword = false,
  passwordRequirements = []
}) => {
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);

  const togglePasswordVisibility = () => setIsPasswordVisible(!isPasswordVisible);

  const passwordRequirementsUi = passwordRequirements.map((requirement, index) => (
    <div key={index} className="auth-password-requirement">
      <span className="auth-password-icon">
        {requirement.passed ? '✓' : '✗'}
      </span>
      <span className="auth-password-text">{requirement.text}</span>
    </div>
  ));

  return (
    <div className="auth-password-input">
      <div
        id="password-field"
        type={isPasswordVisible ? 'text' : 'password'}
        onClick={togglePasswordVisibility}
        readOnly={false}
        className="auth-password-input-field"
      />
      {isPasswordVisible && (
        <button
          type="button"
          className="auth-password-toggle"
          onClick={togglePasswordVisibility}
          aria-label="Hide password"
        >
          <svg
            width={16}
            height={16}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            aria-hidden="true"
          >
            <path d="M13 2L1 12h4a4 4 0 0 1 4 4v4a4 4 0 0 1-4 4H5a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4h8z" />
            <circle cx=12 cy=12 r=4 />
          </svg>
        </button>
      )}
      <button
        type="button"
        className="auth-password-toggle"
        onClick={togglePasswordVisibility}
        aria-label="Show password"
        style={{ display: isPasswordVisible ? 'none' : 'block' }}
      >
        <svg
          width={16}
          height={16}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          aria-hidden="true"
        >
          <path d="M13 2L1 12h4a4 4 0 0 1 4 4v4a4 4 0 0 1-4 4H5a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4h8z" />
          <circle cx=12 cy=12 r=4 />
        </svg>
      </button>
    </div>
  );
};

export default PasswordInput;