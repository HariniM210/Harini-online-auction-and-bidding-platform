import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Icon from '../components/common/Icon';
import categories from '../data/categories';
import gavel from '../assets/images/seller-gavel.webp';
import airpods from '../assets/images/browse/airpods.webp';
import handbag from '../assets/images/browse/handbag.webp';
import smartwatch from '../assets/images/browse/smartwatch.webp';
import painting from '../assets/images/browse/painting.webp';
import sneakers from '../assets/images/browse/sneakers.webp';
import books from '../assets/images/browse/books.webp';
import camera from '../assets/images/camera.webp';
import laptop from '../assets/images/laptop.webp';
import watch from '../assets/images/watch.webp';
import record from '../assets/images/record-player.webp';
import '../styles/browse.css';
const names=[...categories.filter(c=>c.id!=='all-categories').map(c=>c.name),'Sports','Others'];
const seed=[['Apple AirPods Pro','Electronics',12500,airpods,62],['Michael Kors Handbag','Fashion',0,handbag,42,24],['Samsung Galaxy Watch','Electronics',8200,smartwatch,84],['Vintage Painting','Collectibles',0,painting,68,48],['Nike Air Force 1','Sports',5750,sneakers,34],['The Great Gatsby Book','Books & Media',850,books,-2],['Canon EOS 90D DSLR Camera','Electronics',52000,camera,90],['Apple MacBook Air M2','Electronics',78500,laptop,100],['Seiko Automatic Watch','Watches',24000,watch,110],['Vintage Record Player','Collectibles',16500,record,120]];
const epoch=Date.now();
const items=seed.map(([title,category,bid,image,end,start=0],i)=>({id:i+1,title,category,bid,image,end:epoch+end*3600000,start:epoch+start*3600000,created:epoch-i*3600000}));
const statusOf=(a,now)=>a.end<=now?'Ended':a.start>now?'Upcoming':'Active';
const money=n=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n);
function remaining(ms){const m=Math.max(0,Math.ceil(ms/60000));return `${Math.floor(m/1440)}d ${Math.floor(m%1440/60)}h ${m%60}m`;}
export default function BrowseAuctions(){
 const [params,setParams]=useSearchParams(); const selected=params.getAll('category').filter(n=>names.includes(n));
 const [search,setSearch]=useState(''),[min,setMin]=useState(''),[max,setMax]=useState(''),[status,setStatus]=useState('All'),[sort,setSort]=useState('featured'),[page,setPage]=useState(1),[saved,setSaved]=useState([]),[detail,setDetail]=useState(null),[now,setNow]=useState(()=>Date.now());
 useEffect(()=>{const timer=setInterval(()=>setNow(Date.now()),1000);return ()=>clearInterval(timer);},[]);
 useEffect(()=>{if(!detail)return;const close=e=>{if(e.key==='Escape')setDetail(null)};window.addEventListener('keydown',close);return()=>window.removeEventListener('keydown',close)},[detail]);
 const changeCategories=next=>{setParams(next.map(n=>['category',n]));setPage(1)};
 const reset=()=>{changeCategories([]);setSearch('');setMin('');setMax('');setStatus('All');setSort('featured');setPage(1)};
 const invalid=min!==''&&max!==''&&Number(min)>Number(max);
 const filtered=invalid?[]:items.filter(a=>(!selected.length||selected.includes(a.category))&&`${a.title} ${a.category}`.toLowerCase().includes(search.trim().toLowerCase())&&(min===''||a.bid>=Number(min))&&(max===''||a.bid<=Number(max))&&(status==='All'||statusOf(a,now)===status));
 filtered.sort((a,b)=>sort==='ending'?a.end-b.end:sort==='newest'?b.created-a.created:sort==='low'?a.bid-b.bid:sort==='high'?b.bid-a.bid:a.id-b.id);
 const pages=Math.max(1,Math.ceil(filtered.length/6)),current=Math.min(page,pages),visible=filtered.slice((current-1)*6,current*6);
 return <div className="browse-page"><section className="browse-hero"><div><h1>Discover Amazing <span>Auctions</span></h1><p>Bid. Win. Own something special!</p><small>Demo marketplace · No live transactions</small></div><img src={gavel} alt=""/></section>
 <div className="browse-layout"><aside className="browse-filters"><h2> <Icon name="layers"/> Filters</h2><fieldset><legend>Categories</legend>{names.map(n=><label key={n}><input type="checkbox" checked={selected.includes(n)} onChange={()=>changeCategories(selected.includes(n)?selected.filter(v=>v!==n):[...selected,n])}/>{n} ({items.filter(a=>a.category===n).length})</label>)}</fieldset><fieldset><legend>Price Range (₹)</legend><div className="browse-price"><input aria-label="Minimum price" type="number" min="0" placeholder="Min" value={min} onChange={e=>{setMin(e.target.value);setPage(1)}}/><span>–</span><input aria-label="Maximum price" type="number" min="0" placeholder="Max" value={max} onChange={e=>{setMax(e.target.value);setPage(1)}}/></div><input aria-label="Maximum price slider" type="range" min="0" max="100000" step="500" value={max===''?100000:Math.min(100000,Number(max))} onChange={e=>{setMax(e.target.value);setPage(1)}}/>{invalid&&<small role="alert">Minimum must not exceed maximum.</small>}</fieldset><fieldset><legend>Auction Status</legend>{['All','Active','Upcoming','Ended'].map(s=><label key={s}><input type="radio" name="browse-status" checked={status===s} onChange={()=>{setStatus(s);setPage(1)}}/>{s} Auctions</label>)}</fieldset><button className="browse-primary" onClick={reset}>↻ Reset Filters</button></aside>
 <section className="browse-results"><div className="browse-toolbar"><label className="browse-search"><Icon name="search"/><input aria-label="Search auctions" placeholder="Search for auctions..." value={search} onChange={e=>{setSearch(e.target.value);setPage(1)}}/></label><label className="browse-sort">Sort by: <select value={sort} onChange={e=>{setSort(e.target.value);setPage(1)}}><option value="featured">Featured</option><option value="ending">Ending Soon</option><option value="newest">Newest First</option><option value="low">Lowest Price</option><option value="high">Highest Price</option></select></label></div>
 <div className="browse-grid">{visible.map(a=>{const s=statusOf(a,now),liked=saved.includes(a.id);return <article className="browse-card" key={a.id}><div className="browse-image"><img src={a.image} alt={a.title}/><span className={'browse-status '+s.toLowerCase()}>{s}</span><button className={'browse-heart '+(liked?'liked':'')} aria-label={`${liked?'Remove':'Save'} ${a.title} (preview)`} aria-pressed={liked} onClick={()=>setSaved(old=>liked?old.filter(id=>id!==a.id):[...old,a.id])}><Icon name="heart"/></button></div><div className="browse-card-body"><h3>{a.title}</h3><p className="browse-category"><Icon name="tag" size={16}/>{a.category}</p><div className="browse-bid"><span><Icon name="clock" size={20}/>{s==='Ended'?'Auction ended':`${remaining((s==='Upcoming'?a.start:a.end)-now)} ${s==='Upcoming'?'to start':'left'}`}</span><div><small>{s==='Ended'?'Final demo bid':'Current Bid'}</small><strong>{money(a.bid)}</strong></div></div><button className="browse-primary" disabled={s==='Ended'} onClick={()=>setDetail(a)}><Icon name="gavel" size={20}/>{s==='Ended'?'Auction Ended':'View Auction'}</button></div></article>})}</div>
 {!visible.length&&<div className="browse-empty"><h2>No matching auctions</h2><p>Try a different search or reset your filters.</p><button className="browse-primary" onClick={reset}>Reset Filters</button></div>}
 <div className="browse-pagination"><p>Showing {filtered.length?(current-1)*6+1:0} – {Math.min(current*6,filtered.length)} of {filtered.length} auctions</p><nav aria-label="Auction pages"><button disabled={current===1} onClick={()=>setPage(current-1)}>‹</button>{Array.from({length:pages},(_,i)=><button key={i} aria-current={current===i+1?'page':undefined} onClick={()=>setPage(i+1)}>{i+1}</button>)}<button disabled={current===pages} onClick={()=>setPage(current+1)}>›</button></nav></div><p className="browse-note">Demo listings. Hearts are temporary previews; no bids or watchlist records are saved.</p></section></div>
 {detail&&<div className="browse-overlay" onClick={()=>setDetail(null)}><section role="dialog" aria-modal="true" aria-label="Auction preview" className="browse-dialog" onClick={e=>e.stopPropagation()}><button autoFocus className="browse-close" onClick={()=>setDetail(null)} aria-label="Close preview">×</button><img src={detail.image} alt={detail.title}/><h2>{detail.title}</h2><p>{detail.category} · {statusOf(detail,now)}</p><h3>{money(detail.bid)}</h3><p>Demo preview. Full auction details and bidding will be connected in a later phase.</p><button className="browse-primary" onClick={()=>setDetail(null)}>Back to browsing</button></section></div>}
 </div>;
}
